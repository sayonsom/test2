import json
import requests
from datetime import datetime
from typing import Dict, Union
import logging

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def transform_brazil_energy_data(json_data: Dict) -> Dict[str, Dict[str, float]]:
    """
    Transform Brazilian energy data into a standardized format with specific energy metrics,
    broken down by zones.
    
    Args:
        json_data (dict): Input JSON data from the Brazilian energy API
        
    Returns:
        dict: Transformed energy data with standardized metrics per zone
    """
    # Initialize output dictionary for each region
    regions = ['sudesteECentroOeste', 'sul', 'nordeste', 'norte']
    result = {}
    
    # Template for energy metrics
    energy_metrics_template = {
        "BAT": 0.0,  # Battery storage
        "COL": 0.0,  # Coal
        "GEO": 0.0,  # Geothermal
        "NG": 0.0,   # Natural gas
        "NUC": 0.0,  # Nuclear
        "OES": 0.0,  # Other energy sources
        "OIL": 0.0,  # Oil
        "OTH": 0.0,  # Other
        "PS": 0.0,   # Pumped storage
        "SNB": 0.0,  # Solar new baseline
        "SUN": 0.0,  # Solar
        "UES": 0.0,  # Unspecified
        "WAT": 0.0,  # Water/Hydroelectric
        "WND": 0.0,  # Wind
    }
    
    try:
        for region in regions:
            if region in json_data:
                # Create new metrics dictionary for this region
                result[region] = energy_metrics_template.copy()
                region_data = json_data[region]['geracao']
                
                # Aggregate hydroelectric (WAT)
                result[region]["WAT"] = region_data.get('hidraulica', 0.0)
                if region == 'sudesteECentroOeste':
                    # Add Itaipu generation to hydroelectric for Southeast/Center-West
                    result[region]["WAT"] += region_data.get('itaipu50HzBrasil', 0.0)
                    result[region]["WAT"] += region_data.get('itaipu60Hz', 0.0)
                
                # Nuclear (NUC)
                result[region]["NUC"] = region_data.get('nuclear', 0.0)
                
                # Wind (WND)
                result[region]["WND"] = region_data.get('eolica', 0.0)
                
                # Solar (SUN)
                result[region]["SUN"] = region_data.get('solar', 0.0)
                
                # Thermal generation is categorized as coal
                result[region]["COL"] = region_data.get('termica', 0.0)
                
                # Round all values for this region to 2 decimal places
                result[region] = {k: round(v, 2) for k, v in result[region].items()}
        
    except Exception as e:
        logger.error(f"Error processing energy data: {str(e)}")
        raise
    
    return result

def brazil(url: str) -> Dict:
    """
    Fetch energy data from the specified URL.
    
    Args:
        url (str): The URL to fetch data from
        
    Returns:
        dict: The JSON response data
    """
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching data from {url}: {str(e)}")
        raise

def main():
    # Test data
    test_data = {
        "Data": "2025-02-12T21:11:00-03:00",
        "sudesteECentroOeste": {
            "geracao": {
                "total": 54052.4063,
                "hidraulica": 40393.08,
                "termica": 2957.43213,
                "eolica": 17.0,
                "nuclear": 1978.28955,
                "solar": 17.066515,
                "itaipu50HzBrasil": 3025.62,
                "itaipu60Hz": 5663.92139
            },
            "cargaVerificada": 57513.2227,
            "importacao": 7949.27148,
            "exportacao": 4488.45654
        },
        "sul": {
            "geracao": {
                "total": 14315.0381,
                "hidraulica": 12511.3076,
                "termica": 1065.92847,
                "eolica": 736.8021,
                "nuclear": 0.0,
                "solar": 1.0
            },
            "cargaVerificada": 18804.2773,
            "importacao": 4489.23926,
            "exportacao": 0.0
        },
        "nordeste": {
            "geracao": {
                "total": 15890.668,
                "hidraulica": 6373.65,
                "termica": 404.233643,
                "eolica": 9112.784,
                "nuclear": 0.0,
                "solar": -0.000204931945
            },
            "cargaVerificada": 15685.6807,
            "importacao": 1716.312,
            "exportacao": 1921.54773
        },
        "norte": {
            "geracao": {
                "total": 15838.1016,
                "hidraulica": 14839.3643,
                "termica": 987.33,
                "eolica": 11.4074745,
                "nuclear": 0.0,
                "solar": 0.0
            },
            "cargaVerificada": 8094.066,
            "importacao": 0.0,
            "exportacao": 7744.03564
        }
    }

    # Test with sample data
    logger.info("Testing with sample data...")
    try:
        result = transform_brazil_energy_data(test_data)
        print("\nTest Data Results:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        logger.error(f"Error processing test data: {str(e)}")

    # Test with live API data (outside Indian IP address is required)
    if 1 == 0:
        api_url = "https://tr.ons.org.br/Content/GetBalancoEnergetico/null"
        logger.info(f"Fetching live data from {api_url}...")
        try:
            live_data = brazil(api_url)
            result = transform_brazil_energy_data(live_data)
            print("\nLive API Results:")
            print(json.dumps(result, indent=2))
        except Exception as e:
            logger.error(f"Error processing live data: {str(e)}")

if __name__ == "__main__":
    main()