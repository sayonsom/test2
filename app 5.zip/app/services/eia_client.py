# services/eia_client.py
import aiohttp
from datetime import datetime, timedelta
from typing import Dict, List
from core.constants import EnergySource
from core.schemas import EnergyMetricsCreate
import logging
from services.metrics import calculate_carbon_metrics, save_carbon_metrics
from sqlalchemy.orm import Session
from urllib.parse import urlencode

logger = logging.getLogger(__name__)

class EIAClient:
    def __init__(self, api_key: str, base_url: str = "https://api.eia.gov/v2", db: Session = None):
        self.api_key = api_key
        self.base_url = base_url
        self.session = None
        self.db = db

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()

    async def get_energy_data(self, region: str, start_time: datetime) -> List[EnergyMetricsCreate]:
        # Get previous hour's datetime
        previous_hour = start_time - timedelta(hours=1)
        # Set start time to previous hour
        start = previous_hour.replace(minute=0, second=0, microsecond=0)
        
        # Format time for API request
        formatted_start = start.strftime("%Y-%m-%dT%H")
        
        logger.info(f"Fetching data for {region} from {formatted_start}")
        
        endpoint = f"{self.base_url}/electricity/rto/fuel-type-data/data/"
        params = {
            "frequency": "hourly",
            "data[0]": "value",
            "facets[respondent][]": region,
            "start": formatted_start,
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "offset": 0,
            "length": 5000,
            "api_key": self.api_key
        }

        logger.info(f"Full API request: {endpoint}?{urlencode(params)}")

        async with self.session.get(endpoint, params=params) as response:
            response.raise_for_status()
            data = await response.json()
            
            # Add debug logging for API response
            logger.info(f"Response status: {response.status}")
            logger.info(f"Number of records received: {len(data.get('response', {}).get('data', []))}")
            
            return self._parse_response_hourly(data, region)

    def _parse_response_hourly(self, data: Dict, region: str) -> List[EnergyMetricsCreate]:
        metrics_list = []
        timestamp_data = {}
        
        # Add debug logging
        logger.info("Processing response data:")
        
        for record in data.get("response", {}).get("data", []):
            period = datetime.fromisoformat(record.get("period"))
            if period not in timestamp_data:
                timestamp_data[period] = {source.name: 0.0 for source in EnergySource}
            
            source = record.get("fueltype")
            if source in EnergySource.__members__:
                timestamp_data[period][source] = float(record.get("value", 0))
        
        # Add debug logging for timestamps
        logger.info(f"Unique timestamps found: {len(timestamp_data)}")
        logger.info(f"Timestamps: {sorted(timestamp_data.keys())}")
        
        # Create EnergyMetricsCreate objects for each timestamp
        for timestamp, metrics in sorted(timestamp_data.items()):
            # Add debug logging for each metric being saved
            logger.info(f"Processing metrics for timestamp: {timestamp}")
            
            # Calculate and save carbon intensity metrics
            if self.db:
                carbon_metrics = calculate_carbon_metrics(metrics)
                save_carbon_metrics(self.db, region, timestamp, carbon_metrics)
                logger.info(f"Saved carbon intensity metrics for {region} at {timestamp} with values: {carbon_metrics}")
            
            metrics_list.append(EnergyMetricsCreate(
                timestamp=timestamp,
                region=region,
                **metrics
            ))
        
        logger.info(f"Total metrics objects created: {len(metrics_list)}")
        return metrics_list