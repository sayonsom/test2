import json
import requests
from datetime import datetime, timedelta
import pandas as pd
from typing import Dict, List
import logging
from pathlib import Path
import csv
from io import StringIO

# Set up logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

def get_latest_csv_url(date: datetime = None) -> str:
    """
    Generate the URL for the CSV file based on provided date or current date.
    
    Args:
        date (datetime, optional): The date to get data for. If None, uses current date.
    
    Returns:
        str: URL for the CSV file
    """
    if date is None:
        date = datetime.now()
        
    url = f"https://www.eskom.co.za/dataportal/wp-content/uploads/{date.year:04d}/{date.month:02d}/Station_Build_Up_Yesterday.csv"
    return url

def map_sa_energy_sources(row: Dict) -> Dict[str, float]:
    """
    Map South African energy sources to standardized metrics.
    """
    return {
        "region": "southAfrica",
        "updatedAt": datetime.now().isoformat(),
        "BAT": 0.0,  # Battery storage (not present in data)
        "COL": float(row.get('Thermal_Generation', 0)),  # Coal/Thermal
        "GEO": 0.0,  # Geothermal (not present in data)
        "NG": (float(row.get('Eskom_Gas_Generation', 0)) + 
               float(row.get('Dispatchable_IPP_OCGT', 0))),  # Natural gas
        "NUC": float(row.get('Nuclear_Generation', 0)),  # Nuclear
        "OES": float(row.get('Other_RE', 0)),  # Other energy sources
        "OIL": float(row.get('Eskom_OCGT_Generation', 0)),  # Oil (OCGT)
        "OTH": 0.0,  # Other
        "PS": float(row.get('Pumped_Water_Generation', 0)),  # Pumped storage
        "SNB": 0.0,  # Solar new baseline (not present in data)
        "SUN": (float(row.get('PV', 0)) + 
                float(row.get('CSP', 0))),  # Solar (PV + CSP)
        "UES": 0.0,  # Unspecified
        "WAT": float(row.get('Hydro_Water_Generation', 0)),  # Hydroelectric
        "WND": float(row.get('Wind', 0))  # Wind
    }

def transform_sa_energy_data(csv_data: str) -> Dict[str, Dict[str, float]]:
    """
    Transform South African energy data into standardized hourly metrics.
    
    Args:
        csv_data (str): CSV data as string
        
    Returns:
        dict: Dictionary with hourly energy metrics
    """
    try:
        # Read CSV data
        df = pd.read_csv(StringIO(csv_data))
        
        # Convert to datetime and sort
        df['Date_Time_Hour_Beginning'] = pd.to_datetime(df['Date_Time_Hour_Beginning'])
        df = df.sort_values('Date_Time_Hour_Beginning')
        
        # Get the last 24 hours of data
        last_24_hours = df.tail(24)
        
        result = {}
        
        # Process each hour
        for _, row in last_24_hours.iterrows():
            hour_key = row['Date_Time_Hour_Beginning'].strftime('%Y-%m-%d %H:00')
            result[hour_key] = map_sa_energy_sources(row)
            
            # Round all values to 2 decimal places
            result[hour_key] = {k: round(v, 2) for k, v in result[hour_key].items()}
            
    except Exception as e:
        logger.error(f"Error processing SA energy data: {str(e)}")
        raise
        
    return result

def southAfrica(url: str = None, date: datetime = None) -> str:
    """
    Fetch South African energy data from the specified URL.
    
    Args:
        url (str, optional): The URL to fetch data from. If None, generates URL based on date.
        date (datetime, optional): The date to fetch data for. If None, uses current date.
        
    Returns:
        str: The CSV data as string
    """
    if url is None:
        url = get_latest_csv_url(date)
        
    try:
        response = requests.get(url)
        response.raise_for_status()
        return response.text
    except requests.exceptions.RequestException as e:
        logger.error(f"Error fetching data from {url}: {str(e)}")
        raise

def main():
    # Test with sample data
    sample_data = """Date_Time_Hour_Beginning,Thermal_Gen_Excl_Pumping_and_SCO,Eskom_OCGT_SCO_Pumping,Eskom_Gas_SCO_Pumping,Hydro_Water_SCO_Pumping,Pumped_Water_SCO_Pumping,Thermal_Generation,Nuclear_Generation,International_Imports,Eskom_OCGT_Generation,Eskom_Gas_Generation,Dispatchable_IPP_OCGT,Hydro_Water_Generation,Pumped_Water_Generation,IOS_Excl_ILS_and_MLR,ILS_Usage,Manual_Load_Reduction_MLR,Wind,PV,CSP,Other_RE
2024-02-12 00:00:00,20500,0,0,0,0,20500,1000,1200,100,50,30,800,1500,0,0,0,2000,0,100,50
2024-02-12 01:00:00,21000,0,0,0,0,21000,1000,1200,150,60,35,750,1400,0,0,0,1800,0,50,50"""

    logger.info("Testing with sample data...")
    try:
        result = transform_sa_energy_data(sample_data)
        print("\nTest Data Results:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        logger.error(f"Error processing test data: {str(e)}")

    # Try to fetch and process live data
    logger.info("Fetching live data...")
    try:
        csv_data = southAfrica()
        result = transform_sa_energy_data(csv_data)
        print("\nLive Data Results:")
        print(json.dumps(result, indent=2))
    except Exception as e:
        logger.error(f"Error processing live data: {str(e)}")

if __name__ == "__main__":
    main()