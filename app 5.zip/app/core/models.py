# core/models.py
from sqlalchemy import Column, DateTime, Float, String, UniqueConstraint
from .database import Base, engine, db_session

class EnergyMetrics(Base):
    __tablename__ = "energy_metrics"
    
    timestamp = Column(DateTime, primary_key=True)
    region = Column(String, primary_key=True)
    BAT = Column(Float)
    COL = Column(Float)
    GEO = Column(Float)
    NG = Column(Float)
    NUC = Column(Float)
    OES = Column(Float)
    OIL = Column(Float)
    OTH = Column(Float)
    PS = Column(Float)
    SNB = Column(Float)
    SUN = Column(Float)
    UES = Column(Float)
    WAT = Column(Float)
    WND = Column(Float)

    # Add unique constraint for timestamp and region combination
    __table_args__ = (
        UniqueConstraint('timestamp', 'region', name='uix_timestamp_region'),
    )

class CarbonIntensityMetrics(Base):
    __tablename__ = "carbon_intensity_metrics"

    timestamp = Column(DateTime, primary_key=True)
    region = Column(String, primary_key=True)
    carbon_intensity = Column(Float, nullable=False)
    renewable_percentage = Column(Float, nullable=False)
    low_carbon_percentage = Column(Float, nullable=False)
    fossil_fuel_percentage = Column(Float, nullable=False)

    def __repr__(self):
        return f"<CarbonIntensityMetrics(region={self.region}, timestamp={self.timestamp})>"

    # Add unique constraint
    __table_args__ = (
        UniqueConstraint('region', 'timestamp', name='carbon_intensity_metrics_region_timestamp_key'),
    )

# Function to recreate all tables
def init_db():
    Base.metadata.drop_all(bind=engine)
    Base.metadata.create_all(bind=engine)