from sqlalchemy import create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os
import logging

logger = logging.getLogger(__name__)

# Create data directory if it doesn't exist
data_dir = "/app/data"
db_file = f"{data_dir}/energy_metrics.db"

try:
    os.makedirs(data_dir, exist_ok=True)
    logger.info(f"Data directory exists or created at {data_dir}")
    
    # Log directory permissions
    dir_stat = os.stat(data_dir)
    logger.info(f"Data directory permissions: {oct(dir_stat.st_mode)[-3:]}")
    
    # Check if database file exists
    if os.path.exists(db_file):
        file_stat = os.stat(db_file)
        logger.info(f"Database file exists at {db_file}")
        logger.info(f"Database file permissions: {oct(file_stat.st_mode)[-3:]}")
    else:
        logger.info(f"Database file will be created at {db_file}")
        
except Exception as e:
    logger.error(f"Error creating data directory: {str(e)}")
    raise

SQLITE_URL = f"sqlite:///{db_file}"  # Note the 4 forward slashes for absolute path
logger.info(f"Using database URL: {SQLITE_URL}")

engine = create_engine(SQLITE_URL, echo=False)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Create the SessionLocal
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
db_session = SessionLocal()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

