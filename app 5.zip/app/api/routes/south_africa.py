from fastapi import APIRouter, HTTPException
from datetime import datetime
import logging
from typing import Dict

from services.southAfrica import southAfrica, transform_sa_energy_data

router = APIRouter(prefix="/api/southAfrica", tags=["South Africa"])

logger = logging.getLogger(__name__)

@router.get("/{date}")
async def get_sa_energy_data(date: str) -> Dict[str, Dict[str, float]]:
    """
    Get South African energy generation data for the last 24 hours from the specified date.
    
    Args:
        date (str): Date in format YYYY-MM-DD
        
    Returns:
        Dict: Hourly energy generation data
    """
    try:
        # Validate date format
        datetime.strptime(date, "%Y-%m-%d")
        
        # Fetch and transform the data
        csv_data = southAfrica()
        result = transform_sa_energy_data(csv_data)
        
        return result
        
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail="Invalid date format. Please use YYYY-MM-DD"
        )
    except Exception as e:
        logger.error(f"Error processing South Africa energy data: {str(e)}")
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching energy data: {str(e)}"
        ) 