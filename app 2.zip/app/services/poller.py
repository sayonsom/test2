# services/poller.py
import asyncio
import logging
from datetime import datetime, timedelta
from typing import List
from sqlalchemy.orm import Session
from core.database import SessionLocal
from core.models import EnergyMetrics
from core.schemas import EnergyMetricsCreate
from services.eia_client import EIAClient
from sqlalchemy.dialects.sqlite import insert
from sqlalchemy import update

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EnergyPoller:
   def __init__(self, api_key: str, regions: List[str], poll_interval: int = 86400):
       self.api_key = api_key
       self.regions = regions
       self.poll_interval = poll_interval
       self.running = False
       logger.info(f"Initialized daily poller for regions: {regions}")

   async def start(self):
       self.running = True
       logger.info("Starting poller service")
       
       try:
           # Immediate first poll when service starts
           start_time = datetime.utcnow()
           logger.info(f"Starting initial poll cycle at {start_time}")
           await self.poll_regions()
           end_time = datetime.utcnow()
           logger.info(f"Completed initial poll cycle. Duration: {end_time - start_time}")
       except Exception as e:
           logger.error(f"Initial polling error: {str(e)}", exc_info=True)

       # Continue with daily schedule
       while self.running:
           try:
               # Calculate time until next midnight UTC
               current_time = datetime.utcnow()
               next_midnight = (current_time + timedelta(days=1)).replace(
                   hour=0, minute=0, second=0, microsecond=0
               )
               seconds_until_next_run = (next_midnight - current_time).total_seconds()
               
               logger.info(f"Waiting {seconds_until_next_run} seconds until next poll cycle")
               await asyncio.sleep(seconds_until_next_run)
               
               # Run the poll at midnight
               start_time = datetime.utcnow()
               logger.info(f"Starting daily poll cycle at {start_time}")
               await self.poll_regions()
               end_time = datetime.utcnow()
               logger.info(f"Completed daily poll cycle. Duration: {end_time - start_time}")
               
           except Exception as e:
               logger.error(f"Polling error: {str(e)}", exc_info=True)
               await asyncio.sleep(300)  # Wait 5 minutes on error before retrying

   async def stop(self):
       self.running = False
       logger.info("Stopping poller service")

   async def save_metrics(self, db: Session, metrics: EnergyMetricsCreate):
       # Convert Pydantic model to dict
       metrics_dict = metrics.dict()
       
       # Create insert statement
       stmt = insert(EnergyMetrics).values(**metrics_dict)
       
       # Add ON CONFLICT clause for upsert behavior
       stmt = stmt.on_conflict_do_update(
           index_elements=['timestamp', 'region'],
           set_=metrics_dict
       )
       
       try:
           db.execute(stmt)
           db.commit()
           logger.info(f"Successfully upserted data for {metrics.region} at {metrics.timestamp}")
       except Exception as e:
           db.rollback()
           logger.error(f"Error upserting data: {str(e)}")
           raise

   async def poll_regions(self):
       async with EIAClient(self.api_key) as client:
           current_time = datetime.utcnow()
           db = SessionLocal()
           try:
               for region in self.regions:
                   try:
                       metrics = await client.get_energy_data(region, current_time)
                       await self.save_metrics(db, metrics)
                   except Exception as e:
                       logger.error(f"Error polling region {region}: {str(e)}")
                       continue
           finally:
               db.close()