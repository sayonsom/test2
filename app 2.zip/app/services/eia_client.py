# services/eia_client.py
import aiohttp
from datetime import datetime, timedelta
from typing import Dict
from core.constants import EnergySource
from core.schemas import EnergyMetricsCreate
import logging
from services.metrics import calculate_carbon_metrics, save_carbon_metrics
from sqlalchemy.orm import Session

logger = logging.getLogger(__name__)

class EIAClient:
    def __init__(self, api_key: str, base_url: str = "https://api.eia.gov/v2", db: Session = None):
        self.api_key = api_key
        self.base_url = base_url
        self.session = None
        self.db = db

    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.close()

    async def get_energy_data(self, region: str, start_time: datetime) -> EnergyMetricsCreate:
        # Get previous day's date
        previous_day = start_time - timedelta(days=1)
        # Set start time to previous day at 00:00
        start = previous_day.replace(hour=0, minute=0, second=0, microsecond=0)
        # Set end time to previous day at 23:00
        end = previous_day.replace(hour=23, minute=0, second=0, microsecond=0)
        
        # Format times for API request
        formatted_start = start.strftime("%Y-%m-%dT%H")
        formatted_end = end.strftime("%Y-%m-%dT%H")
        
        logger.info(f"Fetching data for {region} from {formatted_start} to {formatted_end}")
        
        endpoint = f"{self.base_url}/electricity/rto/fuel-type-data/data/"
        params = {
            "frequency": "hourly",
            "data[0]": "value",
            "facets[respondent][]": region,
            "start": formatted_start,
            "end": formatted_end,
            "sort[0][column]": "period",
            "sort[0][direction]": "desc",
            "offset": 0,
            "length": 5000,
            "api_key": self.api_key
        }

        async with self.session.get(endpoint, params=params) as response:
            response.raise_for_status()
            data = await response.json()
            return self._parse_response(data, region, start)

    def _parse_response(self, data: Dict, region: str, timestamp: datetime) -> EnergyMetricsCreate:
        metrics = {source.name: 0.0 for source in EnergySource}
        
        for record in data.get("response", {}).get("data", []):
            source = record.get("fueltype")
            if source in EnergySource.__members__:
                metrics[source] = float(record.get("value", 0))

        # Calculate and save carbon intensity metrics
        if self.db:
            carbon_metrics = calculate_carbon_metrics(metrics)
            save_carbon_metrics(self.db, region, timestamp, carbon_metrics)
            logger.info(f"Saved carbon intensity metrics for {region} at {timestamp}")

        return EnergyMetricsCreate(
            timestamp=timestamp,
            region=region,
            **metrics
        )