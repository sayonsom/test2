# services/metrics.py
from typing import Dict, Any
from enum import Enum
from datetime import datetime
from sqlalchemy.orm import Session
from sqlalchemy.dialects.postgresql import insert
from core.models import EnergyMetrics, CarbonIntensityMetrics

class EmissionCategory(str, Enum):
    RENEWABLE = "Renewable"
    FOSSIL = "Fossil"
    LOW_CARBON = "Low-carbon"

# Combined lifecycle and operational emission factors (gCO2eq/kWh)
EMISSION_FACTORS = {
    "BAT": {"lifecycle": 301, "operational": 0, "category": EmissionCategory.RENEWABLE},  # Battery discharge
    "COL": {"lifecycle": 820, "operational": 760, "category": EmissionCategory.FOSSIL},  # Coal
    "GEO": {"lifecycle": 38, "operational": 0, "category": EmissionCategory.RENEWABLE},  # Geothermal
    "NG": {"lifecycle": 490, "operational": 370, "category": EmissionCategory.FOSSIL},   # Natural Gas
    "NUC": {"lifecycle": 12, "operational": 0, "category": EmissionCategory.LOW_CARBON}, # Nuclear
    "OES": {"lifecycle": 301, "operational": 0, "category": EmissionCategory.RENEWABLE},  # Other energy storage
    "OIL": {"lifecycle": 650, "operational": 406, "category": EmissionCategory.FOSSIL},  # Oil
    "OTH": {"lifecycle": 700, "operational": 575, "category": EmissionCategory.FOSSIL},  # Unknown/Other
    "PS": {"lifecycle": 301, "operational": 0, "category": EmissionCategory.RENEWABLE},   # Pumped storage
    "SNB": {"lifecycle": 45, "operational": 0, "category": EmissionCategory.RENEWABLE},   # Solar with battery
    "SUN": {"lifecycle": 45, "operational": 0, "category": EmissionCategory.RENEWABLE},   # Solar
    "UES": {"lifecycle": 301, "operational": 0, "category": EmissionCategory.RENEWABLE},  # Unknown storage
    "WAT": {"lifecycle": 24, "operational": 0, "category": EmissionCategory.RENEWABLE},   # Hydro
    "WND": {"lifecycle": 11, "operational": 0, "category": EmissionCategory.RENEWABLE},   # Wind
}

def calculate_carbon_metrics(energy_data: Dict[str, float]) -> Dict[str, float]:
    """
    Calculate carbon intensity and energy mix percentages using Electricity Maps methodology.
    """
    # Calculate total generation
    total_generation = sum(
        value for key, value in energy_data.items() 
        if key in EMISSION_FACTORS
    )
    
    if total_generation == 0:
        return {
            "carbon_intensity": 0,
            "renewable_percentage": 0,
            "low_carbon_percentage": 0,
            "fossil_fuel_percentage": 0
        }

    # Calculate lifecycle carbon intensity
    total_carbon = sum(
        energy_data[source] * EMISSION_FACTORS[source]["lifecycle"]
        for source in EMISSION_FACTORS.keys()
        if source in energy_data
    )
    
    carbon_intensity = total_carbon / total_generation if total_generation > 0 else 0

    # Calculate generation by category
    renewable_generation = sum(
        energy_data.get(source, 0)
        for source, factors in EMISSION_FACTORS.items()
        if factors["category"] == EmissionCategory.RENEWABLE and source in energy_data
    )

    low_carbon_generation = renewable_generation + sum(
        energy_data.get(source, 0)
        for source, factors in EMISSION_FACTORS.items()
        if factors["category"] == EmissionCategory.LOW_CARBON and source in energy_data
    )

    fossil_generation = sum(
        energy_data.get(source, 0)
        for source, factors in EMISSION_FACTORS.items()
        if factors["category"] == EmissionCategory.FOSSIL and source in energy_data
    )

    # Calculate percentages
    renewable_percentage = (renewable_generation / total_generation * 100) if total_generation > 0 else 0
    low_carbon_percentage = (low_carbon_generation / total_generation * 100) if total_generation > 0 else 0
    fossil_fuel_percentage = (fossil_generation / total_generation * 100) if total_generation > 0 else 0

    return {
        "carbon_intensity": round(carbon_intensity, 2),
        "renewable_percentage": round(renewable_percentage, 2),
        "low_carbon_percentage": round(low_carbon_percentage, 2),
        "fossil_fuel_percentage": round(fossil_fuel_percentage, 2)
    }

def save_carbon_metrics(db: Session, region: str, timestamp: datetime, metrics: Dict[str, float]):
    """
    Save carbon metrics to the database, updating existing records if they exist for the same timestamp and region.
    """
    stmt = insert(CarbonIntensityMetrics).values(
        region=region,
        timestamp=timestamp,
        **metrics
    )
    
    # Add ON CONFLICT clause to update existing records
    stmt = stmt.on_conflict_do_update(
        constraint='carbon_intensity_metrics_region_timestamp_key',  # You'll need to create this unique constraint
        set_=metrics
    )
    
    db.execute(stmt)
    db.commit()