from enum import Enum

class EnergySource(str, Enum):
    BAT = "Battery storage"
    COL = "Coal"
    GEO = "Geothermal"
    NG = "Natural Gas"
    NUC = "Nuclear"
    OES = "Other energy storage"
    OIL = "Petroleum"
    OTH = "Other"
    PS = "Pumped storage"
    SNB = "Solar with battery"
    SUN = "Solar"
    UES = "Unknown storage"
    WAT = "Hydro"
    WND = "Wind"

