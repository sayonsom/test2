# main.py
import logging
import asyncio
from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from datetime import datetime, timedelta
from typing import List, Dict
from routers.carbon_intensity import router as carbon_intensity_router
import os

logging.basicConfig(level=logging.WARNING)
logger = logging.getLogger(__name__)

from core.database import get_db, engine, Base, db_session
from core.models import EnergyMetrics
from services.poller import EnergyPoller
from core.schemas import EnergyMetricsResponse
from services.eia_client import EIAClient

# Create tables
logger.info("Attempting to create database tables...")
try:
    Base.metadata.create_all(bind=engine)
    logger.info("Database tables created successfully")
except Exception as e:
    logger.error(f"Error creating tables: {str(e)}")
    raise

app = FastAPI(title="Energy Metrics Service")

# Add the carbon intensity metrics router
app.include_router(carbon_intensity_router)

# Configure from environment
API_KEY = os.getenv("EIA_API_KEY")
REGIONS = os.getenv("EIA_REGIONS", "").split(",")
POLL_INTERVAL = int(os.getenv("POLL_INTERVAL", "3600"))

# Initialize poller
poller = EnergyPoller(API_KEY, REGIONS, POLL_INTERVAL)

# Initialize EIA client after app creation
eia_client = EIAClient(api_key=API_KEY, db=db_session)

@app.on_event("startup")
async def startup_event():
   asyncio.create_task(poller.start())

@app.on_event("shutdown")
async def shutdown_event():
   await poller.stop()

@app.get("/health")
async def health_check():
   return {"status": "healthy"}

@app.get("/metrics/{region}", response_model=List[EnergyMetricsResponse])
async def get_metrics(
    region: str, 
    start_date: str = None,
    db: Session = Depends(get_db)
):
    """
    Get energy metrics for a specific region.
    If start_date is provided, returns full 24 hours of data for that date.
    If not provided, returns last 24 hours of data.
    start_date format: YYYY-MM-DD
    """
    query = db.query(EnergyMetrics).filter(EnergyMetrics.region == region)
    
    if start_date:
        try:
            # Parse the start date
            start = datetime.strptime(start_date, "%Y-%m-%d")
            # Calculate end date (next day)
            end = start + timedelta(days=1)
            
            # Get all data between start date 00:00 and end date 00:00
            query = query.filter(
                EnergyMetrics.timestamp >= start,
                EnergyMetrics.timestamp < end
            )
        except ValueError:
            raise HTTPException(
                status_code=400, 
                detail="Invalid date format. Use YYYY-MM-DD"
            )
    else:
        # Last 24 hours
        cutoff = datetime.utcnow() - timedelta(hours=24)
        query = query.filter(EnergyMetrics.timestamp >= cutoff)
    
    results = query.order_by(EnergyMetrics.timestamp.desc()).all()
    
    if not results:
        raise HTTPException(
            status_code=404,
            detail=f"No data found for region {region} on date {start_date}"
        )
    
    return results

@app.get("/test-db")
async def test_db(db: Session = Depends(get_db)):
    try:
        # Try to write a test record
        test_metric = EnergyMetrics(
            timestamp=datetime.utcnow(),
            region="TEST",
            BAT=1.0,
            COL=1.0,
            GEO=1.0,
            NG=1.0,
            NUC=1.0,
            OES=1.0,
            OIL=1.0,
            OTH=1.0,
            PS=1.0,
            SNB=1.0,
            SUN=1.0,
            UES=1.0,
            WAT=1.0,
            WND=1.0
        )
        db.add(test_metric)
        db.commit()
        return {"status": "success", "message": "Test record written"}
    except Exception as e:
        return {"status": "error", "message": str(e)}
    

@app.get("/last-polls")
async def get_last_polls(db: Session = Depends(get_db)):
    try:
        # Query the latest timestamp for each region
        latest_polls = db.query(
            EnergyMetrics.region,
            func.max(EnergyMetrics.timestamp).label('last_poll'),
            func.count(EnergyMetrics.timestamp).label('total_records')
        ).group_by(EnergyMetrics.region).all()
        
        # Format the response
        result = {}
        current_time = datetime.utcnow()
        
        for region, last_poll, total_records in latest_polls:
            time_diff = current_time - last_poll
            result[region] = {
                "last_poll": last_poll.isoformat(),
                "minutes_ago": round(time_diff.total_seconds() / 60, 2),
                "total_records": total_records,
                "status": "OK" if time_diff.total_seconds() < 7200 else "DELAYED"  # 2 hours threshold
            }
            
        return {
            "current_time": current_time.isoformat(),
            "regions": result
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))