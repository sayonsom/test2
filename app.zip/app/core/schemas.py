from datetime import datetime
from pydantic import BaseModel, Field
from typing import Optional
from .constants import EnergySource

class EnergyMetricsBase(BaseModel):
    timestamp: datetime
    region: str
    BAT: Optional[float] = Field(default=0.0)
    COL: Optional[float] = Field(default=0.0)  
    GEO: Optional[float] = Field(default=0.0)
    NG: Optional[float] = Field(default=0.0)
    NUC: Optional[float] = Field(default=0.0)
    OES: Optional[float] = Field(default=0.0)
    OIL: Optional[float] = Field(default=0.0)
    OTH: Optional[float] = Field(default=0.0)
    PS: Optional[float] = Field(default=0.0)
    SNB: Optional[float] = Field(default=0.0)
    SUN: Optional[float] = Field(default=0.0)
    UES: Optional[float] = Field(default=0.0)
    WAT: Optional[float] = Field(default=0.0)
    WND: Optional[float] = Field(default=0.0)

    class Config:
        from_attributes = True

class EnergyMetricsCreate(EnergyMetricsBase):
    pass

class EnergyMetricsResponse(EnergyMetricsBase):
    pass

