# routers/carbon_intensity.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import Dict, Any
from datetime import datetime

from core.database import get_db
from core.models import EnergyMetrics
from services.metrics import calculate_carbon_metrics, save_carbon_metrics

router = APIRouter()

@router.get("/carbon-intensity/{region}")
def get_carbon_intensity(
    region: str,
    db: Session = Depends(get_db)
) -> Dict[str, Any]:
    """
    Get the latest carbon intensity metrics for a specific region.
    """
    # Get the latest energy metrics for the region
    latest_metrics = (
        db.query(EnergyMetrics)
        .filter(EnergyMetrics.region == region)
        .order_by(EnergyMetrics.timestamp.desc())
        .first()
    )

    if not latest_metrics:
        raise HTTPException(
            status_code=404,
            detail="No data available for the specified region"
        )

    # Convert the energy metrics to a dictionary
    energy_data = {
        key: getattr(latest_metrics, key)
        for key in ["BAT", "COL", "GEO", "NG", "NUC", "OES", "OIL", 
                   "OTH", "PS", "SNB", "SUN", "UES", "WAT", "WND"]
        if hasattr(latest_metrics, key)
    }

    # Calculate carbon metrics
    carbon_metrics = calculate_carbon_metrics(energy_data)
    
    # Save to database
    save_carbon_metrics(db, region, latest_metrics.timestamp, carbon_metrics)

    # Return the response
    return {
        "timestamp": latest_metrics.timestamp.isoformat(),
        "region": region,
        **carbon_metrics,
        "energy_mix": energy_data
    }