# services/poller.py
import asyncio
import logging
from datetime import datetime
from typing import List
from sqlalchemy.orm import Session
from core.database import SessionLocal
from core.models import EnergyMetrics
from services.eia_client import EIAClient

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class EnergyPoller:
   def __init__(self, api_key: str, regions: List[str], poll_interval: int = 3600):
       self.api_key = api_key
       self.regions = regions
       self.poll_interval = poll_interval
       self.running = False
       logger.info(f"Initialized poller for regions: {regions}")

   async def start(self):
       self.running = True
       logger.info("Starting poller service")
       while self.running:
           try:
               start_time = datetime.utcnow()
               logger.info(f"Starting poll cycle at {start_time}")
               await self.poll_regions()
               end_time = datetime.utcnow()
               logger.info(f"Completed poll cycle. Duration: {end_time - start_time}")
               await asyncio.sleep(self.poll_interval)
           except Exception as e:
               logger.error(f"Polling error: {str(e)}", exc_info=True)
               await asyncio.sleep(60)

   async def poll_regions(self):
       async with EIAClient(self.api_key) as client:
           current_time = datetime.utcnow()
           logger.info(f"Polling {len(self.regions)} regions")
           
           tasks = []
           for region in self.regions:
               logger.debug(f"Creating task for region: {region}")
               tasks.append(client.get_energy_data(region, current_time))
           
           results = await asyncio.gather(*tasks, return_exceptions=True)
           success_count = 0
           
           with SessionLocal() as db:
               for region, result in zip(self.regions, results):
                   if isinstance(result, Exception):
                       logger.error(f"Failed to poll region {region}: {str(result)}")
                       continue
                   try:
                       self._save_metrics(db, result)
                       success_count += 1
                       logger.debug(f"Saved metrics for region: {region}")
                   except Exception as e:
                       logger.error(f"Failed to save metrics for {region}: {str(e)}")
           
           logger.info(f"Poll cycle complete. Success: {success_count}/{len(self.regions)}")

   def _save_metrics(self, db: Session, metrics):
       try:
           db_metrics = EnergyMetrics(**metrics.model_dump())
           db.merge(db_metrics)
           db.commit()
       except Exception as e:
           logger.error(f"Database error: {str(e)}")
           db.rollback()
           raise